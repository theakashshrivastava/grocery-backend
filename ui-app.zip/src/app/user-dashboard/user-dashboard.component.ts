import { Component, OnInit } from '@angular/core';
import { OrderService } from '../services/order.service';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-user-dashboard',
  imports: [CommonModule, MatTableModule, MatButtonModule, MatIconModule],
  templateUrl: './user-dashboard.component.html',
  styleUrl: './user-dashboard.component.css'
})
export class UserDashboardComponent implements OnInit {

  items: any[] = [];
  orderItems: any[] = [];
  userId: number = 1;

  columns: string[] = ['name', 'stockQuantity', 'price', 'action'];
  orderColumns: string[] = ['name', 'quantity', 'price', 'remove'];

  constructor(private orderService: OrderService) {}

  ngOnInit(): void {
    this.orderService.getItems().subscribe(data => this.items = data);
  }

  addItem(item: any): void {
    const addedItem = {
      name: item.name,
      stockQuantity: 1,
      price: item.price,
      userId: this.userId
    };
    this.orderItems = [...this.orderItems, addedItem]; // 🔁 force change detection
  }

  removeItem(index: number): void {
    this.orderItems = this.orderItems.filter((_, i) => i !== index); // ✅ triggers update
  }

  submitOrder(): void {
    this.orderService.placeOrder(this.userId, this.orderItems).subscribe(response => {
      alert(response);
      this.orderItems = [];
    });
  }

}
