import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { GroceryItem } from '../model/GroceryItem';

@Injectable({
  providedIn: 'root'
})
export class OrderService {

  private apiUrl = 'http://localhost:8080/users/orders';
  private apiUrl1 = 'http://localhost:8080/users/grocery-items';

  constructor(private http: HttpClient) { }

  getItems(): Observable<GroceryItem[]> {
    return this.http.get<GroceryItem[]>(this.apiUrl1);
  }

  placeOrder(userId: number, groceryRequest: any[]): Observable<string> {
    return this.http.post(`/users/orders?userId=${userId}`, groceryRequest, {
      responseType: 'text' as const
    });
  }



}
