import { Component } from '@angular/core';
import { HeaderComponent } from "./header/header.component";
import { FooterComponent } from "./footer/footer.component";
import { Router, RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';
import { GroceryHighlightComponent } from "./grocery-highlight/grocery-highlight.component";


@Component({
  selector: 'app-root',
  imports: [RouterOutlet, CommonModule, HeaderComponent, FooterComponent, GroceryHighlightComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  constructor(public router: Router){}
  title = 'grocery-app-ui';
  
  isHomeRouteActive(): boolean {
    const excludedRoutes = ['/browse', '/signin', '/register'];
    return !excludedRoutes.some(route => this.router.url.startsWith(route));
  }  

}
