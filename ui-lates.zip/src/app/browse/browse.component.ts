import { Component, OnInit } from '@angular/core';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { debounceTime, switchMap } from 'rxjs/operators';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatInputModule } from '@angular/material/input';
import { MatCardModule } from '@angular/material/card';
import { MatChipsModule } from '@angular/material/chips';
import { MatIconModule } from '@angular/material/icon';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatButtonModule } from '@angular/material/button';
import { CommonModule } from '@angular/common';
import { trigger, transition, style, animate } from '@angular/animations';
import { BrowseService } from '../service/browse.service';
import { Router } from '@angular/router';

const iconMap: { [key: string]: string } = {
  rice: 'restaurant',
  sugar: 'local_cafe',
  apple: 'eco',
  banana: 'emoji_food_beverage',
  milk: 'local_drink',
  bread: 'bakery_dining',
  oil: 'science',
  salt: 'grain'
};

@Component({
  selector: 'app-browse',
  standalone: true,
  templateUrl: './browse.component.html',
  styleUrls: ['./browse.component.css'],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatAutocompleteModule,
    MatInputModule,
    MatCardModule,
    MatIconModule,
    MatGridListModule,
    MatButtonModule,
    MatChipsModule
],
  animations: [
    trigger('fadeIn', [
      transition(':enter', [
        style({ opacity: 0 }),
        animate('600ms ease-in', style({ opacity: 1 }))
      ])
    ])
  ]
})
export class BrowseComponent implements OnInit {
  searchControl = new FormControl('');
  showNoMatchMessage = false;
  filteredOptions: string[] = [];
  showFeaturedItems = false;
  
featuredItems: string[] = [
  'Organic Mangoes',
  'Fresh Berries',
  'Gaming Laptop',
  'Decor Items',
  'Notepad',
  'Grooming kit',
  'Headphones',
  'Turbo Charger',
  'Laptop Table'
];

displayedItems: string[] = [];
  topItems: any[] = [];

  constructor(private http: HttpClient, 
    private browseService: BrowseService,
  private router: Router) {}

  
  onSignUpClick() {
    const newUser = {
      username: 'bruce_wayne',
      email: 'bruce@capg.com',
      password: 'abcd5678'
    };

    
    this.browseService.registerPublicUser(newUser).subscribe({
      next: (res) => {
        console.log('User registered:', res);
        this.router.navigate(['/login']);
      },
      error: (err) => {
        console.error('Registration failed:', err);
      }
    });
  }

  


  
  ngOnInit(): void {
    this.loadTopItems();

  this.searchControl.valueChanges
    .pipe(
      debounceTime(300),
      switchMap(value => this.browseService.searchItems(value || ''))
    )
    .subscribe(data => this.filteredOptions = data);
}

toggleFeaturedItems(): void {
  this.showFeaturedItems = !this.showFeaturedItems;
  if (this.showFeaturedItems) {
    this.displayedItems = this.shuffleAndPick(this.featuredItems, 3 + Math.floor(Math.random() * 2));
  }
}

shuffleAndPick(array: string[], count: number): string[] {
  return [...array].sort(() => 0.5 - Math.random()).slice(0, count);
}

  
  loadTopItems(): void {
    this.browseService.getTopItems().subscribe(data => {
      this.topItems = data.map(item => ({
        ...item,
        icon: iconMap[item.name.toLowerCase()] || 'shopping_cart'
      }));
    });
  }  
}
