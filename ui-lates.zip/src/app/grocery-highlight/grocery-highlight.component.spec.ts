import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GroceryHighlightComponent } from './grocery-highlight.component';

describe('GroceryHighlightComponent', () => {
  let component: GroceryHighlightComponent;
  let fixture: ComponentFixture<GroceryHighlightComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [GroceryHighlightComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GroceryHighlightComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
