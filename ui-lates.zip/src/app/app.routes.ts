import { Routes } from '@angular/router';
import { BrowseComponent } from './browse/browse.component';
import { RegisterComponent } from './auth/register/register.component';
import { LoginComponent } from './auth/login/login.component';

export const routes: Routes = [
    {path:'browse',component:BrowseComponent},
    {path:'register',component:RegisterComponent},
    {path:'signin',component:LoginComponent}
];
