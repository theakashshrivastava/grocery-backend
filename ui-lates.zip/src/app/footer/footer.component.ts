import { Component } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-footer',
  imports: [RouterModule, MatIconModule],
  templateUrl: './footer.component.html',
  styleUrl: './footer.component.css'
})
export class FooterComponent {
  footerText_1: string = 'Pavan IT Solutions Pvt Ltd';
  footerText_2: string = 'Innovating with passion. Serving with purpose.';
  footerText_3: string = '2025 Pavan IT Solutions Pvt Ltd. All rights reserved.';

}
