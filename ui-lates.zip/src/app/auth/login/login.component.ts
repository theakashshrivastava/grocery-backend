import { Component } from '@angular/core';
import { AuthService } from '../../service/auth.service';
import { User } from '../../models/user.model';
import { MatInputModule } from "@angular/material/input";
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  imports: [MatInputModule,FormsModule]
})
export class LoginComponent {
  user: Partial<User> = {
    email: '',
    password: ''
  };

  constructor(private authService: AuthService) {}

  onLogin() {
    this.authService.login(this.user as User).subscribe({
      next: token => {
        localStorage.setItem('token', token);
        alert('Login successful!');
      },
      error: err => alert('Login failed: ' + err.error)
    });
  }
}
