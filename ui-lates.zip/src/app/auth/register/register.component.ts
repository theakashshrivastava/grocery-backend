import { Component } from '@angular/core';
import { AuthService } from '../../service/auth.service';
import { User } from '../../models/user.model';
import { FormsModule } from '@angular/forms';
import { MatInputModule } from "@angular/material/input";
import { MatAutocompleteModule } from "@angular/material/autocomplete";
import { MatCardContent } from "@angular/material/card";
import { MatIconModule } from '@angular/material/icon';
import { MatCardTitle } from '@angular/material/card';
import { MatCardHeader } from '@angular/material/card';
import { MatCard } from '@angular/material/card';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  imports: [FormsModule, 
    MatInputModule,
    MatAutocompleteModule,
    MatCardContent,
    MatCardTitle,
    MatIconModule,
    MatCardHeader,
    MatCard]
})
export class RegisterComponent {
  user: User = {
    username: '',
    email: '',
    password: '',
    role: 'USER'
  };

  constructor(private authService: AuthService) {}

  onRegister() {
    this.authService.register(this.user).subscribe({
      next: res => alert('Registration successful!'),
      error: err => alert('Registration failed: ' + err.error)
    });
  }
}