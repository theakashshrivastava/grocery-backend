import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BrowseService {
  private apiUrl = environment.apiUrl;
  private registerUrl = 'http://localhost:8080/register';

  constructor(private http: HttpClient) {}

  searchItems(query: string) {
    return this.http.get<string[]>(`${this.apiUrl}/search?query=${query}`);
  }

  getTopItems() {
    return this.http.get<any[]>(`${this.apiUrl}/top-items`);
  }

  
  registerPublicUser(user: any): Observable<any> {
    const params = new HttpParams().set('context', 'public');
    return this.http.post(this.registerUrl, user, { params });
  }
}
