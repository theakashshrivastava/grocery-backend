package com.question.pro.grocery_app.dto;

import java.math.BigDecimal;

public class GroceryRequest {
    private String name;
    private Integer stockQuantity;

    private BigDecimal totalPrice;

    private Long userId;

    public BigDecimal getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(BigDecimal totalPrice) {
        this.totalPrice = totalPrice;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getStockQuantity() {
        return stockQuantity;
    }

    public void setStockQuantity(Integer stockQuantity) {
        this.stockQuantity = stockQuantity;
    }
}
