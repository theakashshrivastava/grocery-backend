package com.question.pro.grocery_app.controller;

import com.question.pro.grocery_app.entity.GroceryItems;
import com.question.pro.grocery_app.entity.Users;
import com.question.pro.grocery_app.repository.GroceryItemsRepository;
import com.question.pro.grocery_app.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@RestController
public class OpenEndPointsController {
    @Autowired
    private UserService userService;
    @Autowired
    private GroceryItemsRepository groceryItemsRepository;

    /**Tested**/
    @PostMapping("/register")
    @ResponseStatus(HttpStatus.CREATED)
    public Users register(@RequestBody Users user){
        return userService.register(user);
    }

//    @PostMapping("/register")
//    @ResponseStatus(HttpStatus.CREATED)
//    public Users register(@RequestBody Users user, @RequestParam(required = false) String context) {
//        if ("public".equalsIgnoreCase(context)) {
//            user.setRole(Users.Role.USER);
//        }
//        return userService.register(user);
//    }


    /**Tested**/
    @PostMapping("/login")
    public String login(@RequestBody Users user){
        return userService.verify(user);
    }

    @GetMapping("/top-items")
    public List<GroceryItems> getRandomTopItems() {
        List<GroceryItems> allItems = groceryItemsRepository.findAll();
        Collections.shuffle(allItems);
        return allItems.stream().limit(5).collect(Collectors.toList());
    }

    @GetMapping("/search")
    public List<String> searchItems(@RequestParam String query) {
        return groceryItemsRepository.findByNameContainingIgnoreCase(query)
                .stream()
                .map(GroceryItems::getName)
                .collect(Collectors.toList());
    }
}
